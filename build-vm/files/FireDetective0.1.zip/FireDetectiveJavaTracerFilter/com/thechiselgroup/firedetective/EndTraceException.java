package com.thechiselgroup.firedetective;

public class EndTraceException extends Throwable {

	private static final long serialVersionUID = 1314007025173185905L;

}
