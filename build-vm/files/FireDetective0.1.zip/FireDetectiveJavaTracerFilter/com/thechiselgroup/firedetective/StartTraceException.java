package com.thechiselgroup.firedetective;

public class StartTraceException extends Throwable {

	private static final long serialVersionUID = 3621658635138983890L;

}
